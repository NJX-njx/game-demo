window.$game.dataManager.resolve(
    {
        "player-attack": {
            "0": "assets/audios/attack1.wav",
            "1": "assets/audios/attack2.wav"
        },
        "player-dash": {
            "0": "assets/audios/dash.wav"
        },
        "player-jump": {
            "0": "assets/audios/jump1.wav",
            "1": "assets/audios/jump2.wav"
        }
    }
)