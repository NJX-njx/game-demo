window.$game.dataManager.resolve(
    {
        "player": {
            "0": "assets/imgs/像素小人/character.png"
        },
        "enemy": {
            "0": "assets/imgs/敌对生物/creep1.png"
        }
    }
)
