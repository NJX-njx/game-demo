//控制绘画的一些常量
//地图基本尺寸，20x20的格子
const basicSize = 20;
const halfSize = 20;
const offsetSize = 1.6;
